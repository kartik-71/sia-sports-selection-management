import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Users, Trophy, Medal, BarChart3, LogOut, Plus, Search, Trash2, Edit, ClipboardList, Shield, UserPlus, X, Upload, Megaphone,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

interface StudentRow {
  user_id: string;
  full_name: string;
  username: string;
  course: string | null;
  year: number | null;
  role: string;
}

const AdminDashboard = () => {
  const { user, profile, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");
  const [search, setSearch] = useState("");
  const [sportFilter, setSportFilter] = useState("");

  // Data state
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [sports, setSports] = useState<{ id: string; name: string }[]>([]);
  const [achievers, setAchievers] = useState<{ id: string; name: string; sport: string; achievement: string; year: string | null; photo_url: string | null }[]>([]);
  const [announcements, setAnnouncements] = useState<{ id: string; title: string; description: string; created_at: string }[]>([]);
  const [sportEnrollment, setSportEnrollment] = useState<{ sport: string; students: number }[]>([]);
  const [studentSportsMap, setStudentSportsMap] = useState<Record<string, { sport_id: string; name: string }[]>>({});

  // Modals
  const [showAddStudent, setShowAddStudent] = useState(false);
  const [showAddSport, setShowAddSport] = useState(false);
  const [showAddAchiever, setShowAddAchiever] = useState(false);
  const [showEditSport, setShowEditSport] = useState<{ id: string; name: string } | null>(null);
  const [showEditStudent, setShowEditStudent] = useState<StudentRow | null>(null);
  const [showAssignSports, setShowAssignSports] = useState<StudentRow | null>(null);
  const [showAddAnnouncement, setShowAddAnnouncement] = useState(false);

  // Form state
  const [newStudent, setNewStudent] = useState({ fullName: "", email: "", password: "", course: "", year: "1" });
  const [newSport, setNewSport] = useState("");
  const [editSportName, setEditSportName] = useState("");
  const [newAchiever, setNewAchiever] = useState({ name: "", sport: "", achievement: "", year: "" });
  const [achieverPhoto, setAchieverPhoto] = useState<File | null>(null);
  const [editStudentForm, setEditStudentForm] = useState({ full_name: "", course: "", year: 1 });
  const [assignedSportIds, setAssignedSportIds] = useState<string[]>([]);
  const [newAnnouncement, setNewAnnouncement] = useState({ title: "", description: "" });

  useEffect(() => {
    if (!loading && (!user || profile?.role !== "admin")) navigate("/login");
  }, [loading, user, profile, navigate]);

  const fetchAll = async () => {
    const { data: profs } = await supabase.from("profiles").select("user_id, full_name, username, course, year, role").eq("role", "student");
    if (profs) setStudents(profs);

    const { data: sp } = await supabase.from("sports").select("id, name").order("name");
    if (sp) setSports(sp);

    const { data: ach } = await supabase.from("achievers").select("*").order("created_at", { ascending: false });
    if (ach) setAchievers(ach);

    const { data: ann } = await supabase.from("announcements").select("*").order("created_at", { ascending: false });
    if (ann) setAnnouncements(ann);

    // Fetch all student-sport enrollments
    const { data: allEnrollments } = await supabase.from("student_sports").select("user_id, sport_id, sports(name)");
    if (allEnrollments && sp) {
      const map: Record<string, { sport_id: string; name: string }[]> = {};
      allEnrollments.forEach((e: any) => {
        if (!map[e.user_id]) map[e.user_id] = [];
        map[e.user_id].push({ sport_id: e.sport_id, name: e.sports?.name || "Unknown" });
      });
      setStudentSportsMap(map);

      const counts = sp.map(s => ({
        sport: s.name,
        students: allEnrollments.filter((e: any) => e.sport_id === s.id).length,
      }));
      setSportEnrollment(counts);
    }
  };

  useEffect(() => { if (user && profile?.role === "admin") fetchAll(); }, [user, profile]);

  const filteredStudents = students.filter(
    (s) => s.full_name.toLowerCase().includes(search.toLowerCase())
  );

  const handleAddStudent = async () => {
    try {
      const { error } = await supabase.auth.signUp({
        email: newStudent.email,
        password: newStudent.password,
        options: { data: { full_name: newStudent.fullName, username: newStudent.email.split("@")[0], course: newStudent.course, year: newStudent.year, role: "student" } },
      });
      if (error) throw error;
      toast.success("Student added!");
      setShowAddStudent(false);
      setNewStudent({ fullName: "", email: "", password: "", course: "", year: "1" });
      setTimeout(fetchAll, 1000);
    } catch (err: any) { toast.error(err.message); }
  };

  const handleDeleteStudent = async (userId: string) => {
    const { error } = await supabase.from("profiles").delete().eq("user_id", userId);
    if (error) toast.error(error.message);
    else { toast.success("Student removed"); fetchAll(); }
  };

  const handleEditStudent = async () => {
    if (!showEditStudent) return;
    const { error } = await supabase.from("profiles").update({
      full_name: editStudentForm.full_name,
      course: editStudentForm.course,
      year: editStudentForm.year,
    }).eq("user_id", showEditStudent.user_id);
    if (error) toast.error(error.message);
    else { toast.success("Student updated!"); setShowEditStudent(null); fetchAll(); }
  };

  const handleAddSport = async () => {
    if (!newSport.trim()) return;
    const { error } = await supabase.from("sports").insert({ name: newSport.trim() });
    if (error) toast.error(error.message);
    else { toast.success("Sport added!"); setNewSport(""); setShowAddSport(false); fetchAll(); }
  };

  const handleEditSport = async () => {
    if (!showEditSport || !editSportName.trim()) return;
    const { error } = await supabase.from("sports").update({ name: editSportName.trim() }).eq("id", showEditSport.id);
    if (error) toast.error(error.message);
    else { toast.success("Sport updated!"); setShowEditSport(null); fetchAll(); }
  };

  const handleDeleteSport = async (id: string) => {
    const { error } = await supabase.from("sports").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Sport deleted!"); fetchAll(); }
  };

  const handleAddAchiever = async () => {
    let photo_url: string | null = null;
    if (achieverPhoto) {
      const ext = achieverPhoto.name.split(".").pop();
      const path = `${Date.now()}.${ext}`;
      const { error: uploadErr } = await supabase.storage.from("achiever-photos").upload(path, achieverPhoto);
      if (uploadErr) { toast.error("Photo upload failed: " + uploadErr.message); return; }
      const { data: urlData } = supabase.storage.from("achiever-photos").getPublicUrl(path);
      photo_url = urlData.publicUrl;
    }
    const { error } = await supabase.from("achievers").insert({ ...newAchiever, photo_url } as any);
    if (error) toast.error(error.message);
    else { toast.success("Achiever added!"); setNewAchiever({ name: "", sport: "", achievement: "", year: "" }); setAchieverPhoto(null); setShowAddAchiever(false); fetchAll(); }
  };

  const handleDeleteAchiever = async (id: string) => {
    const { error } = await supabase.from("achievers").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Achiever deleted!"); fetchAll(); }
  };

  const handleAttendance = async (userId: string, name: string, status: "present" | "absent") => {
    const { error } = await supabase.from("attendance").upsert({ user_id: userId, status, date: new Date().toISOString().split("T")[0] }, { onConflict: "user_id,date" });
    if (error) toast.error(error.message);
    else toast.success(`${name} marked ${status}`);
  };

  const handleAssignSports = async () => {
    if (!showAssignSports) return;
    const userId = showAssignSports.user_id;
    // Delete existing enrollments
    await supabase.from("student_sports").delete().eq("user_id", userId);
    // Insert new ones
    if (assignedSportIds.length > 0) {
      const rows = assignedSportIds.map(sport_id => ({ user_id: userId, sport_id, selected: true }));
      const { error } = await supabase.from("student_sports").insert(rows);
      if (error) { toast.error(error.message); return; }
    }
    toast.success("Sports assigned!");
    setShowAssignSports(null);
    fetchAll();
  };

  const openAssignSports = (student: StudentRow) => {
    setShowAssignSports(student);
    const existing = studentSportsMap[student.user_id] || [];
    setAssignedSportIds(existing.map(e => e.sport_id));
  };

  const toggleAssignedSport = (sportId: string) => {
    setAssignedSportIds(prev => prev.includes(sportId) ? prev.filter(id => id !== sportId) : [...prev, sportId]);
  };

  const handleAddAnnouncement = async () => {
    if (!newAnnouncement.title.trim() || !newAnnouncement.description.trim()) return;
    const { error } = await supabase.from("announcements").insert(newAnnouncement);
    if (error) toast.error(error.message);
    else { toast.success("Announcement added!"); setNewAnnouncement({ title: "", description: "" }); setShowAddAnnouncement(false); fetchAll(); }
  };

  const handleDeleteAnnouncement = async (id: string) => {
    const { error } = await supabase.from("announcements").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Announcement deleted!"); fetchAll(); }
  };

  const tabs = [
    { id: "overview", label: "Overview", icon: <BarChart3 size={18} /> },
    { id: "students", label: "Students", icon: <Users size={18} /> },
    { id: "sports", label: "Sports", icon: <Trophy size={18} /> },
    { id: "achievers", label: "Achievers", icon: <Medal size={18} /> },
    { id: "announcements", label: "Announcements", icon: <Megaphone size={18} /> },
    { id: "attendance", label: "Attendance", icon: <ClipboardList size={18} /> },
  ];

  if (loading) return <div className="min-h-screen bg-background flex items-center justify-center text-foreground">Loading...</div>;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Shield className="text-secondary" size={28} />
          <span className="font-heading text-xl font-bold">ADMIN <span className="text-gradient-gold">PANEL</span></span>
        </div>
        <button onClick={() => { signOut(); navigate("/"); }} className="flex items-center gap-1 text-sm text-destructive hover:underline">
          <LogOut size={16} /> Logout
        </button>
      </header>

      <div className="flex">
        <aside className="w-60 min-h-[calc(100vh-64px)] bg-card border-r border-border p-4 hidden md:block">
          <nav className="space-y-1">
            {tabs.map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === tab.id ? "gradient-blue text-secondary-foreground" : "text-muted-foreground hover:bg-muted"}`}>
                {tab.icon} {tab.label}
              </button>
            ))}
          </nav>
        </aside>

        <main className="flex-1 p-6">
          <div className="flex md:hidden gap-2 mb-6 overflow-x-auto">
            {tabs.map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap ${activeTab === tab.id ? "gradient-blue text-secondary-foreground" : "bg-muted text-muted-foreground"}`}>
                {tab.icon} {tab.label}
              </button>
            ))}
          </div>

          {/* OVERVIEW */}
          {activeTab === "overview" && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="font-heading text-2xl font-bold text-foreground">Admin Dashboard</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: "Total Students", value: students.length, icon: <Users size={24} />, color: "text-primary" },
                  { label: "Total Sports", value: sports.length, icon: <Trophy size={24} />, color: "text-accent" },
                  { label: "Achievers", value: achievers.length, icon: <Medal size={24} />, color: "text-secondary" },
                ].map((s, i) => (
                  <div key={i} className="gradient-card rounded-xl p-5 border border-border">
                    <div className={`${s.color} mb-2`}>{s.icon}</div>
                    <p className="font-heading text-2xl font-bold text-foreground">{s.value}</p>
                    <p className="text-muted-foreground text-sm">{s.label}</p>
                  </div>
                ))}
              </div>
              <div className="gradient-card rounded-xl p-6 border border-border">
                <h3 className="font-heading text-lg font-semibold text-foreground mb-4">Students by Sport</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={sportEnrollment}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 15%, 20%)" />
                    <XAxis dataKey="sport" stroke="hsl(215, 15%, 55%)" fontSize={12} />
                    <YAxis stroke="hsl(215, 15%, 55%)" fontSize={12} />
                    <Tooltip contentStyle={{ background: "hsl(220, 18%, 11%)", border: "1px solid hsl(220, 15%, 20%)", borderRadius: 8 }} />
                    <Bar dataKey="students" fill="hsl(210, 80%, 50%)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* STUDENTS */}
          {activeTab === "students" && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <h2 className="font-heading text-2xl font-bold text-foreground">Manage Students</h2>
                <button onClick={() => setShowAddStudent(true)} className="gradient-gold text-primary-foreground font-medium px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:opacity-90">
                  <UserPlus size={16} /> Add Student
                </button>
              </div>
              <div className="flex gap-3 flex-wrap">
                <div className="relative flex-1 min-w-[200px]">
                  <Search size={16} className="absolute left-3 top-3 text-muted-foreground" />
                  <input placeholder="Search students..." value={search} onChange={(e) => setSearch(e.target.value)}
                    className="w-full bg-muted border border-border rounded-lg pl-10 pr-4 py-2.5 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary" />
                </div>
              </div>
              <div className="overflow-x-auto rounded-xl border border-border">
                <table className="w-full text-sm">
                  <thead className="bg-muted">
                    <tr>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Name</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Course</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Year</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Sports</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStudents.map((s) => (
                      <tr key={s.user_id} className="border-t border-border hover:bg-muted/50 transition-colors">
                        <td className="px-4 py-3 text-foreground font-medium">{s.full_name}</td>
                        <td className="px-4 py-3 text-muted-foreground">{s.course || "-"}</td>
                        <td className="px-4 py-3 text-foreground">Y{s.year}</td>
                        <td className="px-4 py-3">
                          <div className="flex flex-wrap gap-1">
                            {(studentSportsMap[s.user_id] || []).map(sp => (
                              <span key={sp.sport_id} className="px-2 py-0.5 rounded-full text-xs bg-primary/20 text-primary">{sp.name}</span>
                            ))}
                            {!(studentSportsMap[s.user_id]?.length) && <span className="text-muted-foreground text-xs">None</span>}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-2">
                            <button onClick={() => openAssignSports(s)} className="text-primary hover:text-primary/80" title="Assign Sports"><Trophy size={16} /></button>
                            <button onClick={() => { setShowEditStudent(s); setEditStudentForm({ full_name: s.full_name, course: s.course || "", year: s.year || 1 }); }} className="text-secondary hover:text-secondary/80"><Edit size={16} /></button>
                            <button onClick={() => handleDeleteStudent(s.user_id)} className="text-destructive hover:text-destructive/80"><Trash2 size={16} /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {filteredStudents.length === 0 && <tr><td colSpan={5} className="px-4 py-6 text-center text-muted-foreground">No students found</td></tr>}
                  </tbody>
                </table>
              </div>

              {/* Add Student Modal */}
              {showAddStudent && (
                <Modal title="Add Student" onClose={() => setShowAddStudent(false)}>
                  <input placeholder="Full Name" value={newStudent.fullName} onChange={e => setNewStudent({ ...newStudent, fullName: e.target.value })} className="modal-input" />
                  <input placeholder="Email" type="email" value={newStudent.email} onChange={e => setNewStudent({ ...newStudent, email: e.target.value })} className="modal-input" />
                  <input placeholder="Password" type="password" value={newStudent.password} onChange={e => setNewStudent({ ...newStudent, password: e.target.value })} className="modal-input" />
                  <select value={newStudent.course} onChange={e => setNewStudent({ ...newStudent, course: e.target.value })} className="modal-input">
                    <option value="">Select Course</option>
                    <option value="BSc IT">BSc IT</option><option value="BCA">BCA</option><option value="BMS">BMS</option><option value="BCom">BCom</option>
                  </select>
                  <select value={newStudent.year} onChange={e => setNewStudent({ ...newStudent, year: e.target.value })} className="modal-input">
                    <option value="1">Year 1</option><option value="2">Year 2</option><option value="3">Year 3</option>
                  </select>
                  <button onClick={handleAddStudent} className="w-full gradient-gold text-primary-foreground font-medium py-2 rounded-lg hover:opacity-90">Add Student</button>
                </Modal>
              )}

              {/* Edit Student Modal */}
              {showEditStudent && (
                <Modal title="Edit Student" onClose={() => setShowEditStudent(null)}>
                  <input placeholder="Full Name" value={editStudentForm.full_name} onChange={e => setEditStudentForm({ ...editStudentForm, full_name: e.target.value })} className="modal-input" />
                  <input placeholder="Course" value={editStudentForm.course} onChange={e => setEditStudentForm({ ...editStudentForm, course: e.target.value })} className="modal-input" />
                  <select value={editStudentForm.year} onChange={e => setEditStudentForm({ ...editStudentForm, year: parseInt(e.target.value) })} className="modal-input">
                    <option value={1}>Year 1</option><option value={2}>Year 2</option><option value={3}>Year 3</option>
                  </select>
                  <button onClick={handleEditStudent} className="w-full gradient-blue text-secondary-foreground font-medium py-2 rounded-lg hover:opacity-90">Save Changes</button>
                </Modal>
              )}

              {/* Assign Sports Modal */}
              {showAssignSports && (
                <Modal title={`Assign Sports — ${showAssignSports.full_name}`} onClose={() => setShowAssignSports(null)}>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {sports.map(sp => (
                      <label key={sp.id} className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-muted cursor-pointer">
                        <input type="checkbox" checked={assignedSportIds.includes(sp.id)} onChange={() => toggleAssignedSport(sp.id)}
                          className="w-4 h-4 rounded border-border text-primary focus:ring-primary" />
                        <span className="text-foreground text-sm">{sp.name}</span>
                      </label>
                    ))}
                    {sports.length === 0 && <p className="text-muted-foreground text-sm">No sports available. Add sports first.</p>}
                  </div>
                  <button onClick={handleAssignSports} className="w-full gradient-blue text-secondary-foreground font-medium py-2 rounded-lg hover:opacity-90">Save Assignments</button>
                </Modal>
              )}
            </div>
          )}

          {/* SPORTS */}
          {activeTab === "sports" && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h2 className="font-heading text-2xl font-bold text-foreground">Manage Sports</h2>
                <button onClick={() => setShowAddSport(true)} className="gradient-blue text-secondary-foreground font-medium px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:opacity-90">
                  <Plus size={16} /> Add Sport
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {sports.map((s) => (
                  <div key={s.id} className="gradient-card rounded-xl p-5 border border-border hover:border-secondary/50 transition-colors">
                    <h3 className="font-heading text-lg font-bold text-foreground">{s.name}</h3>
                    <div className="flex gap-2 mt-3">
                      <button onClick={() => { setShowEditSport(s); setEditSportName(s.name); }} className="text-xs text-secondary hover:underline">Edit</button>
                      <button onClick={() => handleDeleteSport(s.id)} className="text-xs text-destructive hover:underline">Delete</button>
                    </div>
                  </div>
                ))}
              </div>

              {showAddSport && (
                <Modal title="Add Sport" onClose={() => setShowAddSport(false)}>
                  <input placeholder="Sport name" value={newSport} onChange={e => setNewSport(e.target.value)} className="modal-input" />
                  <button onClick={handleAddSport} className="w-full gradient-blue text-secondary-foreground font-medium py-2 rounded-lg hover:opacity-90">Add Sport</button>
                </Modal>
              )}

              {showEditSport && (
                <Modal title="Edit Sport" onClose={() => setShowEditSport(null)}>
                  <input placeholder="Sport name" value={editSportName} onChange={e => setEditSportName(e.target.value)} className="modal-input" />
                  <button onClick={handleEditSport} className="w-full gradient-blue text-secondary-foreground font-medium py-2 rounded-lg hover:opacity-90">Save</button>
                </Modal>
              )}
            </div>
          )}

          {/* ACHIEVERS */}
          {activeTab === "achievers" && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h2 className="font-heading text-2xl font-bold text-foreground">Manage Achievers</h2>
                <button onClick={() => setShowAddAchiever(true)} className="gradient-gold text-primary-foreground font-medium px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:opacity-90">
                  <Plus size={16} /> Add Achiever
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {achievers.map((a) => (
                  <div key={a.id} className="gradient-card rounded-xl p-5 border border-border">
                    {a.photo_url && (
                      <img src={a.photo_url} alt={a.name} className="w-16 h-16 rounded-full object-cover mb-3 border-2 border-primary/30" />
                    )}
                    <h3 className="font-heading text-lg font-bold text-foreground">{a.name}</h3>
                    <p className="text-primary text-sm">{a.sport}</p>
                    <p className="text-muted-foreground text-sm mt-1">{a.achievement}</p>
                    <button onClick={() => handleDeleteAchiever(a.id)} className="text-xs text-destructive hover:underline mt-2">Delete</button>
                  </div>
                ))}
                {achievers.length === 0 && <p className="text-muted-foreground">No achievers yet.</p>}
              </div>

              {showAddAchiever && (
                <Modal title="Add Achiever" onClose={() => setShowAddAchiever(false)}>
                  <input placeholder="Name" value={newAchiever.name} onChange={e => setNewAchiever({ ...newAchiever, name: e.target.value })} className="modal-input" />
                  <input placeholder="Sport" value={newAchiever.sport} onChange={e => setNewAchiever({ ...newAchiever, sport: e.target.value })} className="modal-input" />
                  <input placeholder="Achievement" value={newAchiever.achievement} onChange={e => setNewAchiever({ ...newAchiever, achievement: e.target.value })} className="modal-input" />
                  <input placeholder="Year (e.g. 2024)" value={newAchiever.year} onChange={e => setNewAchiever({ ...newAchiever, year: e.target.value })} className="modal-input" />
                  <label className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground hover:text-foreground transition-colors">
                    <Upload size={16} />
                    <span>{achieverPhoto ? achieverPhoto.name : "Upload Photo"}</span>
                    <input type="file" accept="image/*" className="hidden" onChange={e => setAchieverPhoto(e.target.files?.[0] || null)} />
                  </label>
                  {achieverPhoto && (
                    <img src={URL.createObjectURL(achieverPhoto)} alt="Preview" className="w-16 h-16 rounded-full object-cover border border-border" />
                  )}
                  <button onClick={handleAddAchiever} className="w-full gradient-gold text-primary-foreground font-medium py-2 rounded-lg hover:opacity-90">Add Achiever</button>
                </Modal>
              )}
            </div>
          )}

          {/* ANNOUNCEMENTS */}
          {activeTab === "announcements" && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h2 className="font-heading text-2xl font-bold text-foreground">Manage Announcements</h2>
                <button onClick={() => setShowAddAnnouncement(true)} className="gradient-blue text-secondary-foreground font-medium px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:opacity-90">
                  <Plus size={16} /> Add Announcement
                </button>
              </div>
              <div className="space-y-4">
                {announcements.map((a) => (
                  <div key={a.id} className="gradient-card rounded-xl p-5 border border-border">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="font-heading text-lg font-bold text-foreground">{a.title}</h3>
                        <p className="text-muted-foreground text-sm mt-1">{a.description}</p>
                        <p className="text-muted-foreground/60 text-xs mt-2">{new Date(a.created_at).toLocaleDateString()}</p>
                      </div>
                      <button onClick={() => handleDeleteAnnouncement(a.id)} className="text-destructive hover:text-destructive/80 shrink-0"><Trash2 size={16} /></button>
                    </div>
                  </div>
                ))}
                {announcements.length === 0 && <p className="text-muted-foreground">No announcements yet.</p>}
              </div>

              {showAddAnnouncement && (
                <Modal title="Add Announcement" onClose={() => setShowAddAnnouncement(false)}>
                  <input placeholder="Title" value={newAnnouncement.title} onChange={e => setNewAnnouncement({ ...newAnnouncement, title: e.target.value })} className="modal-input" />
                  <textarea placeholder="Description" value={newAnnouncement.description} onChange={e => setNewAnnouncement({ ...newAnnouncement, description: e.target.value })} className="modal-input min-h-[100px] resize-y" />
                  <button onClick={handleAddAnnouncement} className="w-full gradient-blue text-secondary-foreground font-medium py-2 rounded-lg hover:opacity-90">Add Announcement</button>
                </Modal>
              )}
            </div>
          )}

          {/* ATTENDANCE */}
          {activeTab === "attendance" && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="font-heading text-2xl font-bold text-foreground">Mark Attendance</h2>
              <div className="overflow-x-auto rounded-xl border border-border">
                <table className="w-full text-sm">
                  <thead className="bg-muted">
                    <tr>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Student</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Course</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Today</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((s) => (
                      <tr key={s.user_id} className="border-t border-border">
                        <td className="px-4 py-3 text-foreground font-medium">{s.full_name}</td>
                        <td className="px-4 py-3 text-muted-foreground">{s.course || "-"}</td>
                        <td className="px-4 py-3">
                          <div className="flex gap-2">
                            <button onClick={() => handleAttendance(s.user_id, s.full_name, "present")} className="px-3 py-1 rounded text-xs font-medium bg-accent/20 text-accent hover:bg-accent/30 transition-colors">Present</button>
                            <button onClick={() => handleAttendance(s.user_id, s.full_name, "absent")} className="px-3 py-1 rounded text-xs font-medium bg-destructive/20 text-destructive hover:bg-destructive/30 transition-colors">Absent</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {students.length === 0 && <tr><td colSpan={3} className="px-4 py-6 text-center text-muted-foreground">No students found</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

// Reusable modal component
const Modal = ({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) => (
  <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" onClick={onClose}>
    <div className="bg-card border border-border rounded-xl p-6 w-full max-w-md space-y-4" onClick={e => e.stopPropagation()}>
      <div className="flex items-center justify-between">
        <h3 className="font-heading text-lg font-bold text-foreground">{title}</h3>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
      </div>
      {children}
    </div>
  </div>
);

export default AdminDashboard;
