import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { User, BarChart3, PieChart, Bell, CheckCircle, LogOut, Trophy, Calendar, XCircle } from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart as RPieChart, Pie, Cell,
} from "recharts";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

const StudentDashboard = () => {
  const { user, profile, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");
  const [performanceData, setPerformanceData] = useState<{ month: string; score: number }[]>([]);
  const [attendanceData, setAttendanceData] = useState<{ name: string; value: number; color: string }[]>([]);
  const [announcements, setAnnouncements] = useState<{ title: string; description: string }[]>([]);
  const [mySports, setMySports] = useState<{ sport_id: string; name: string }[]>([]);
  const [allSports, setAllSports] = useState<{ id: string; name: string }[]>([]);
  const [attPercent, setAttPercent] = useState(0);
  const [savingSports, setSavingSports] = useState(false);
  const [selectedSportIds, setSelectedSportIds] = useState<string[]>([]);

  useEffect(() => {
    if (!loading && !user) navigate("/login");
  }, [loading, user, navigate]);

  const fetchSports = async () => {
    if (!user) return;
    const { data: enrollments } = await supabase
      .from("student_sports")
      .select("sport_id, sports(name)")
      .eq("user_id", user.id);
    if (enrollments) {
      const mapped = enrollments.map((e: any) => ({ sport_id: e.sport_id, name: e.sports?.name || "Unknown" }));
      setMySports(mapped);
      setSelectedSportIds(mapped.map(m => m.sport_id));
    }
    const { data: sp } = await supabase.from("sports").select("id, name").order("name");
    if (sp) setAllSports(sp);
  };

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: perf } = await supabase.from("performance").select("month, score").eq("user_id", user.id);
      if (perf && perf.length > 0) setPerformanceData(perf);
      else setPerformanceData([{ month: "No Data", score: 0 }]);

      const { data: att } = await supabase.from("attendance").select("status").eq("user_id", user.id);
      if (att && att.length > 0) {
        const present = att.filter(a => a.status === "present").length;
        const pct = Math.round((present / att.length) * 100);
        setAttPercent(pct);
        setAttendanceData([
          { name: "Present", value: pct, color: "hsl(160, 70%, 45%)" },
          { name: "Absent", value: 100 - pct, color: "hsl(0, 72%, 50%)" },
        ]);
      } else {
        setAttPercent(0);
        setAttendanceData([
          { name: "Present", value: 0, color: "hsl(160, 70%, 45%)" },
          { name: "Absent", value: 100, color: "hsl(0, 72%, 50%)" },
        ]);
      }

      fetchSports();

      const { data: anns } = await supabase.from("announcements").select("title, description").order("created_at", { ascending: false }).limit(5);
      if (anns) setAnnouncements(anns);
    };
    fetchData();
  }, [user]);

  const toggleSport = (sportId: string) => {
    setSelectedSportIds(prev => prev.includes(sportId) ? prev.filter(id => id !== sportId) : [...prev, sportId]);
  };

  const handleSaveSports = async () => {
    if (!user) return;
    setSavingSports(true);
    try {
      await supabase.from("student_sports").delete().eq("user_id", user.id);
      if (selectedSportIds.length > 0) {
        const rows = selectedSportIds.map(sport_id => ({ user_id: user.id, sport_id, selected: false }));
        const { error } = await supabase.from("student_sports").insert(rows);
        if (error) throw error;
      }
      toast.success("Sports updated!");
      fetchSports();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSavingSports(false);
    }
  };

  const tabs = [
    { id: "overview", label: "Overview", icon: <BarChart3 size={18} /> },
    { id: "sports", label: "My Sports", icon: <Trophy size={18} /> },
    { id: "profile", label: "Profile", icon: <User size={18} /> },
    { id: "announcements", label: "Announcements", icon: <Bell size={18} /> },
  ];

  const yearLabel = profile?.year === 1 ? "First Year" : profile?.year === 2 ? "Second Year" : profile?.year === 3 ? "Third Year" : `Year ${profile?.year}`;

  if (loading) return <div className="min-h-screen bg-background flex items-center justify-center text-foreground">Loading...</div>;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Trophy className="text-primary" size={28} />
          <span className="font-heading text-xl font-bold text-gradient-gold">SIA SPORTS</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm text-muted-foreground hidden sm:block">Welcome, {profile?.full_name || "Student"}</span>
          <button onClick={() => { signOut(); navigate("/"); }} className="flex items-center gap-1 text-sm text-destructive hover:underline">
            <LogOut size={16} /> Logout
          </button>
        </div>
      </header>

      <div className="flex">
        <aside className="w-60 min-h-[calc(100vh-64px)] bg-card border-r border-border p-4 hidden md:block">
          <nav className="space-y-1">
            {tabs.map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === tab.id ? "gradient-gold text-primary-foreground" : "text-muted-foreground hover:bg-muted"}`}>
                {tab.icon} {tab.label}
              </button>
            ))}
          </nav>
        </aside>

        <main className="flex-1 p-6">
          <div className="flex md:hidden gap-2 mb-6 overflow-x-auto">
            {tabs.map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap ${activeTab === tab.id ? "gradient-gold text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                {tab.icon} {tab.label}
              </button>
            ))}
          </div>

          {activeTab === "overview" && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="font-heading text-2xl font-bold text-foreground">Dashboard Overview</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="gradient-card rounded-xl p-5 border border-border">
                  <p className="text-muted-foreground text-sm">My Sports</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {mySports.length > 0 ? mySports.map(s => (
                      <span key={s.sport_id} className="px-2 py-0.5 rounded-full text-xs bg-primary/20 text-primary">{s.name}</span>
                    )) : <span className="text-muted-foreground text-sm">None selected</span>}
                  </div>
                </div>
                <div className="gradient-card rounded-xl p-5 border border-border">
                  <p className="text-muted-foreground text-sm">Sports Count</p>
                  <p className="font-heading text-xl font-bold text-primary mt-1">{mySports.length}</p>
                </div>
                <div className="gradient-card rounded-xl p-5 border border-border">
                  <p className="text-muted-foreground text-sm">Attendance</p>
                  <p className="font-heading text-xl font-bold text-foreground mt-1">{attPercent}%</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="gradient-card rounded-xl p-6 border border-border">
                  <h3 className="font-heading text-lg font-semibold text-foreground mb-4">Performance Trend</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 15%, 20%)" />
                      <XAxis dataKey="month" stroke="hsl(215, 15%, 55%)" fontSize={12} />
                      <YAxis stroke="hsl(215, 15%, 55%)" fontSize={12} />
                      <Tooltip contentStyle={{ background: "hsl(220, 18%, 11%)", border: "1px solid hsl(220, 15%, 20%)", borderRadius: 8 }} />
                      <Bar dataKey="score" fill="hsl(45, 100%, 50%)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="gradient-card rounded-xl p-6 border border-border">
                  <h3 className="font-heading text-lg font-semibold text-foreground mb-4">Attendance Breakdown</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <RPieChart>
                      <Pie data={attendanceData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} dataKey="value" label={({ name, value }) => `${name}: ${value}%`}>
                        {attendanceData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                      </Pie>
                      <Tooltip contentStyle={{ background: "hsl(220, 18%, 11%)", border: "1px solid hsl(220, 15%, 20%)", borderRadius: 8 }} />
                    </RPieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {activeTab === "sports" && (
            <div className="animate-fade-in max-w-lg">
              <h2 className="font-heading text-2xl font-bold text-foreground mb-6">Select My Sports</h2>
              <div className="gradient-card rounded-xl p-6 border border-border space-y-3">
                {allSports.map(sp => (
                  <label key={sp.id} className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-muted cursor-pointer">
                    <input type="checkbox" checked={selectedSportIds.includes(sp.id)} onChange={() => toggleSport(sp.id)}
                      className="w-4 h-4 rounded border-border text-primary focus:ring-primary" />
                    <span className="text-foreground text-sm">{sp.name}</span>
                  </label>
                ))}
                {allSports.length === 0 && <p className="text-muted-foreground text-sm">No sports available.</p>}
                <button onClick={handleSaveSports} disabled={savingSports}
                  className="w-full gradient-gold text-primary-foreground font-medium py-2 rounded-lg hover:opacity-90 disabled:opacity-50 mt-4">
                  {savingSports ? "Saving..." : "Save My Sports"}
                </button>
              </div>
            </div>
          )}

          {activeTab === "profile" && (
            <div className="animate-fade-in max-w-lg">
              <h2 className="font-heading text-2xl font-bold text-foreground mb-6">My Profile</h2>
              <div className="gradient-card rounded-xl p-6 border border-border space-y-4">
                {[
                  { label: "Name", value: profile?.full_name || "-" },
                  { label: "Username", value: profile?.username || "-" },
                  { label: "Email", value: user?.email || "-" },
                  { label: "Course", value: profile?.course || "-" },
                  { label: "Year", value: yearLabel },
                  { label: "Sports", value: mySports.length > 0 ? mySports.map(s => s.name).join(", ") : "None" },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between border-b border-border pb-3 last:border-0">
                    <span className="text-muted-foreground text-sm">{item.label}</span>
                    <span className="text-foreground font-medium text-sm">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "announcements" && (
            <div className="animate-fade-in">
              <h2 className="font-heading text-2xl font-bold text-foreground mb-6">Announcements</h2>
              <div className="space-y-4">
                {announcements.length === 0 && <p className="text-muted-foreground">No announcements yet.</p>}
                {announcements.map((a, i) => (
                  <div key={i} className="gradient-card rounded-xl p-5 border border-border hover:border-primary/50 transition-colors">
                    <div className="flex items-start gap-3">
                      <Calendar className="text-primary mt-1 shrink-0" size={20} />
                      <div>
                        <h3 className="font-heading text-base font-semibold text-foreground">{a.title}</h3>
                        <p className="text-muted-foreground text-sm mt-1">{a.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default StudentDashboard;
