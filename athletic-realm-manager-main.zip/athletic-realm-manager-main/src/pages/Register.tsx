import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, UserPlus } from "lucide-react";
import Navbar from "@/components/Navbar";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const Register = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: "", username: "", email: "", password: "", confirmPassword: "", course: "", year: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    if (form.password.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.signUp({
        email: form.email,
        password: form.password,
        options: {
          data: {
            full_name: form.fullName,
            username: form.username,
            course: form.course,
            year: form.year,
            role: "student",
          },
        },
      });
      if (error) throw error;
      toast.success("Registration successful! Please login.");
      navigate("/login");
    } catch (err: any) {
      toast.error(err.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-12 flex items-center justify-center px-4">
        <div className="w-full max-w-md gradient-card rounded-xl border border-border p-8">
          <div className="text-center mb-6">
            <UserPlus className="text-primary mx-auto mb-3" size={40} />
            <h1 className="font-heading text-3xl font-bold text-foreground">Register</h1>
            <p className="text-muted-foreground text-sm mt-1">Create your SIA Sports account</p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input name="fullName" placeholder="Full Name" required value={form.fullName} onChange={handleChange}
              className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
            <input name="username" placeholder="Username" required value={form.username} onChange={handleChange}
              className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
            <input name="email" type="email" placeholder="Email" required value={form.email} onChange={handleChange}
              className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
            <div className="relative">
              <input name="password" type={showPassword ? "text" : "password"} placeholder="Password" required value={form.password} onChange={handleChange}
                className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary pr-12" />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3 text-muted-foreground">
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <input name="confirmPassword" type="password" placeholder="Confirm Password" required value={form.confirmPassword} onChange={handleChange}
              className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
            <select name="course" required value={form.course} onChange={handleChange}
              className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary">
              <option value="">Select Course</option>
              <option value="BSc IT">BSc IT</option>
              <option value="BCA">BCA</option>
              <option value="BMS">BMS</option>
              <option value="BCom">BCom</option>
              <option value="BA">BA</option>
            </select>
            <select name="year" required value={form.year} onChange={handleChange}
              className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary">
              <option value="">Select Year</option>
              <option value="1">First Year</option>
              <option value="2">Second Year</option>
              <option value="3">Third Year</option>
            </select>
            <button type="submit" disabled={loading}
              className="w-full gradient-gold text-primary-foreground font-heading font-semibold py-3 rounded-lg text-lg hover:opacity-90 transition-opacity shadow-gold disabled:opacity-50">
              {loading ? "Registering..." : "Register"}
            </button>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-4">
            Already have an account? <Link to="/login" className="text-primary hover:underline">Login</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;
