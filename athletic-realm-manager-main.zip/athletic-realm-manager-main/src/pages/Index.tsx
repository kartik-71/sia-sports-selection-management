import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Trophy, Target, Users, Medal, ArrowRight } from "lucide-react";
import heroImg from "@/assets/hero-sports.jpg";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { supabase } from "@/integrations/supabase/client";

const sports = [
  { name: "Cricket", icon: "🏏", desc: "Inter-college tournaments and state-level matches" },
  { name: "Football", icon: "⚽", desc: "11-a-side league and futsal championships" },
  { name: "Basketball", icon: "🏀", desc: "3x3 and 5v5 competitive leagues" },
  { name: "Athletics", icon: "🏃", desc: "Track and field events across all distances" },
  { name: "Volleyball", icon: "🏐", desc: "Indoor and beach volleyball competitions" },
  { name: "Table Tennis", icon: "🏓", desc: "Singles and doubles tournaments" },
];

const Index = () => {
  const [achievers, setAchievers] = useState<{ id: string; name: string; sport: string; achievement: string; year: string | null; photo_url: string | null }[]>([]);

  useEffect(() => {
    const fetchAchievers = async () => {
      const { data } = await supabase.from("achievers").select("*").order("created_at", { ascending: false });
      if (data) setAchievers(data);
    };
    fetchAchievers();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <img src={heroImg} alt="Sports stadium" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-background/70" />
        <div className="relative z-10 text-center px-4 animate-fade-in">
          <div className="flex items-center justify-center gap-3 mb-6">
            <Trophy className="text-primary" size={48} />
          </div>
          <h1 className="font-heading text-5xl md:text-7xl font-bold text-foreground mb-4">
            SIA <span className="text-gradient-gold">SPORTS</span> PORTAL
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Selection & Management Portal — Empowering Student Athletes
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="gradient-gold text-primary-foreground font-heading font-semibold px-8 py-3 rounded-lg text-lg hover:opacity-90 transition-opacity shadow-gold"
            >
              Get Started
            </Link>
            <Link
              to="/login"
              className="border border-primary text-primary font-heading font-semibold px-8 py-3 rounded-lg text-lg hover:bg-primary hover:text-primary-foreground transition-colors"
            >
              Login
            </Link>
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="font-heading text-4xl font-bold text-center mb-4">
            About <span className="text-gradient-gold">SIA Sports</span>
          </h2>
          <p className="text-muted-foreground text-center max-w-3xl mx-auto mb-12">
            SIA College fosters athletic excellence through structured sports programs, performance analytics, and competitive opportunities at state and national levels.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { icon: <Trophy size={32} />, label: "15+ Sports", sub: "Wide variety of sports offered" },
              { icon: <Users size={32} />, label: "500+ Athletes", sub: "Active student athletes" },
              { icon: <Medal size={32} />, label: "200+ Medals", sub: "Won in competitions" },
              { icon: <Target size={32} />, label: "50+ Events", sub: "Organized annually" },
            ].map((s, i) => (
              <div
                key={i}
                className="gradient-card rounded-xl p-6 text-center border border-border hover:border-primary/50 transition-colors group"
              >
                <div className="text-primary mb-3 flex justify-center group-hover:scale-110 transition-transform">{s.icon}</div>
                <h3 className="font-heading text-xl font-bold text-foreground">{s.label}</h3>
                <p className="text-muted-foreground text-sm mt-1">{s.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sports Offered */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <h2 className="font-heading text-4xl font-bold text-center mb-12">
            Sports <span className="text-gradient-gold">Offered</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {sports.map((s) => (
              <div
                key={s.name}
                className="bg-background rounded-xl p-6 border border-border hover:border-primary/50 hover:shadow-gold transition-all group cursor-pointer"
              >
                <span className="text-4xl mb-3 block">{s.icon}</span>
                <h3 className="font-heading text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                  {s.name}
                </h3>
                <p className="text-muted-foreground text-sm mt-2">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievers */}
      <section id="achievers" className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="font-heading text-4xl font-bold text-center mb-12">
            Our <span className="text-gradient-gold">Achievers</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {achievers.map((a) => (
              <div
                key={a.id}
                className="gradient-card rounded-xl p-6 border border-border hover:border-primary/50 transition-all text-center group"
              >
                {a.photo_url ? (
                  <img src={a.photo_url} alt={a.name} className="w-20 h-20 rounded-full object-cover mx-auto mb-4 border-2 border-primary/30" />
                ) : (
                  <div className="w-20 h-20 rounded-full gradient-gold flex items-center justify-center mx-auto mb-4 text-primary-foreground font-heading text-xl font-bold">
                    {a.name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()}
                  </div>
                )}
                <h3 className="font-heading text-lg font-bold text-foreground">{a.name}</h3>
                <p className="text-primary text-sm font-semibold mt-1">{a.sport}</p>
                <p className="text-muted-foreground text-xs mt-2">{a.achievement}</p>
              </div>
            ))}
            {achievers.length === 0 && (
              <p className="text-muted-foreground col-span-full text-center">No achievers yet.</p>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
