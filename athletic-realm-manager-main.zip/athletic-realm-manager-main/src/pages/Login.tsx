import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { LogIn, Shield } from "lucide-react";
import Navbar from "@/components/Navbar";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const Login = () => {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: form.email,
        password: form.password,
      });
      if (error) throw error;

      // Check role
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("user_id", data.user.id)
        .maybeSingle();

      if (isAdmin && profile?.role !== "admin") {
        await supabase.auth.signOut();
        toast.error("You are not an admin");
        setLoading(false);
        return;
      }

      toast.success("Login successful!");
      navigate(profile?.role === "admin" ? "/admin" : "/student");
    } catch (err: any) {
      toast.error(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-12 flex items-center justify-center px-4">
        <div className="w-full max-w-md gradient-card rounded-xl border border-border p-8">
          <div className="text-center mb-6">
            {isAdmin ? <Shield className="text-secondary mx-auto mb-3" size={40} /> : <LogIn className="text-primary mx-auto mb-3" size={40} />}
            <h1 className="font-heading text-3xl font-bold text-foreground">{isAdmin ? "Admin Login" : "Student Login"}</h1>
            <p className="text-muted-foreground text-sm mt-1">Access your SIA Sports dashboard</p>
          </div>

          <div className="flex mb-6 bg-muted rounded-lg p-1">
            <button onClick={() => setIsAdmin(false)}
              className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${!isAdmin ? "gradient-gold text-primary-foreground" : "text-muted-foreground"}`}>
              Student
            </button>
            <button onClick={() => setIsAdmin(true)}
              className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${isAdmin ? "gradient-blue text-secondary-foreground" : "text-muted-foreground"}`}>
              Admin
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <input name="email" type="email" placeholder="Email" required value={form.email} onChange={handleChange}
              className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
            <input name="password" type="password" placeholder="Password" required value={form.password} onChange={handleChange}
              className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
            <button type="submit" disabled={loading}
              className={`w-full font-heading font-semibold py-3 rounded-lg text-lg hover:opacity-90 transition-opacity disabled:opacity-50 ${isAdmin ? "gradient-blue text-secondary-foreground shadow-blue" : "gradient-gold text-primary-foreground shadow-gold"}`}>
              {loading ? "Logging in..." : "Login"}
            </button>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-4">
            Don't have an account? <Link to="/register" className="text-primary hover:underline">Register</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
