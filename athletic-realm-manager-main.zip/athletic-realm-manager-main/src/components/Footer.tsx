import { Trophy, Mail, Phone, MapPin } from "lucide-react";

const Footer = () => (
  <footer id="contact" className="bg-card border-t border-border py-12">
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="font-heading text-xl font-bold text-primary mb-4">SIA SPORTS PORTAL</h3>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Empowering student athletes at SIA College through competitive sports, performance tracking, and holistic development.
          </p>
        </div>
        <div>
          <h4 className="font-heading text-lg font-semibold text-foreground mb-4">Quick Links</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><a href="/#about" className="hover:text-primary transition-colors">About Sports</a></li>
            <li><a href="/#achievers" className="hover:text-primary transition-colors">Achievers</a></li>
            <li><a href="/login" className="hover:text-primary transition-colors">Login</a></li>
            <li><a href="/register" className="hover:text-primary transition-colors">Register</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-heading text-lg font-semibold text-foreground mb-4">Contact Us</h4>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-center gap-2"><Mail size={16} className="text-primary" /> sports@siacollege.edu</li>
            <li className="flex items-center gap-2"><Phone size={16} className="text-primary" /> +91 98765 43210</li>
            <li className="flex items-center gap-2"><MapPin size={16} className="text-primary" /> SIA College, Mumbai, India</li>
          </ul>
        </div>
      </div>
      <div className="mt-8 pt-6 border-t border-border text-center text-xs text-muted-foreground">
        © 2026 SIA College Sports Portal. BSc IT Semester 5 Project.
      </div>
    </div>
  </footer>
);

export default Footer;
