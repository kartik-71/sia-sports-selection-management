<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIA Sports Selection & Management Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <i class="fas fa-trophy text-gold me-2 fs-4"></i>
            <span class="brand-text">SIA SPORTS</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#about">About Sports</a></li>
                <li class="nav-item"><a class="nav-link" href="#achievers">Achievers</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <li class="nav-item"><a class="nav-link btn-gold-outline ms-2 px-3" href="register.php">Register</a></li>
                <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero-section d-flex align-items-center justify-content-center text-center">
    <div class="hero-overlay"></div>
    <div class="container position-relative z-1">
        <i class="fas fa-trophy text-gold hero-icon mb-3"></i>
        <h1 class="hero-title">SIA <span class="text-gold">SPORTS</span> PORTAL</h1>
        <p class="hero-subtitle">Selection & Management Portal — Empowering Student Athletes</p>
        <div class="mt-4">
            <a href="register.php" class="btn btn-gold btn-lg me-3">Get Started</a>
            <a href="login.php" class="btn btn-gold-outline btn-lg">Login</a>
        </div>
    </div>
</section>

<!-- About Section -->
<section id="about" class="py-5">
    <div class="container">
        <h2 class="section-title text-center mb-3">About <span class="text-gold">SIA Sports</span></h2>
        <p class="text-muted text-center mb-5 mx-auto" style="max-width:700px;">
            SIA College fosters athletic excellence through structured sports programs, performance analytics, and competitive opportunities.
        </p>
        <div class="row g-4">
            <div class="col-md-3 col-6">
                <div class="stat-card text-center">
                    <i class="fas fa-trophy text-gold fs-2 mb-2"></i>
                    <h3>15+</h3>
                    <p class="text-muted small">Sports Offered</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="stat-card text-center">
                    <i class="fas fa-users text-gold fs-2 mb-2"></i>
                    <h3>500+</h3>
                    <p class="text-muted small">Athletes</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="stat-card text-center">
                    <i class="fas fa-medal text-gold fs-2 mb-2"></i>
                    <h3>200+</h3>
                    <p class="text-muted small">Medals Won</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="stat-card text-center">
                    <i class="fas fa-calendar text-gold fs-2 mb-2"></i>
                    <h3>50+</h3>
                    <p class="text-muted small">Annual Events</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Sports Offered -->
<section class="py-5 bg-card-dark">
    <div class="container">
        <h2 class="section-title text-center mb-5">Sports <span class="text-gold">Offered</span></h2>
        <div class="row g-4">
            <?php
            $sports = mysqli_query($conn, "SELECT * FROM sports");
            while ($sport = mysqli_fetch_assoc($sports)) {
            ?>
            <div class="col-md-4 col-sm-6">
                <div class="sport-card">
                    <span class="sport-icon"><?= htmlspecialchars($sport['icon']) ?></span>
                    <h4><?= htmlspecialchars($sport['name']) ?></h4>
                    <p class="text-muted small"><?= htmlspecialchars($sport['description']) ?></p>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</section>

<!-- Achievers Section -->
<section id="achievers" class="py-5">
    <div class="container">
        <h2 class="section-title text-center mb-5">Our <span class="text-gold">Achievers</span></h2>
        <div class="row g-4">
            <?php
            $achievers = mysqli_query($conn, "SELECT a.*, u.full_name, s.name as sport_name FROM achievers a LEFT JOIN users u ON a.user_id = u.id LEFT JOIN sports s ON a.sport_id = s.id ORDER BY a.id DESC LIMIT 4");
            if (mysqli_num_rows($achievers) > 0) {
                while ($ach = mysqli_fetch_assoc($achievers)) {
            ?>
            <div class="col-lg-3 col-md-6">
                <div class="achiever-card text-center">
                    <div class="achiever-avatar"><?= strtoupper(substr($ach['full_name'] ?? 'NA', 0, 2)) ?></div>
                    <h5><?= htmlspecialchars($ach['full_name'] ?? 'Unknown') ?></h5>
                    <p class="text-gold small fw-bold"><?= htmlspecialchars($ach['sport_name'] ?? '') ?></p>
                    <p class="text-muted small"><?= htmlspecialchars($ach['achievement']) ?></p>
                </div>
            </div>
            <?php }
            } else { ?>
            <div class="col-12 text-center text-muted">
                <p>Achievers will be displayed here once added by admin.</p>
            </div>
            <?php } ?>
        </div>
    </div>
</section>

<!-- Footer -->
<footer id="contact" class="py-5 bg-card-dark border-top border-secondary">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <h5 class="text-gold fw-bold">SIA SPORTS PORTAL</h5>
                <p class="text-muted small">Empowering student athletes at SIA College through competitive sports and performance tracking.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled small">
                    <li><a href="#about" class="text-muted text-decoration-none">About Sports</a></li>
                    <li><a href="#achievers" class="text-muted text-decoration-none">Achievers</a></li>
                    <li><a href="login.php" class="text-muted text-decoration-none">Login</a></li>
                    <li><a href="register.php" class="text-muted text-decoration-none">Register</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <ul class="list-unstyled small text-muted">
                    <li><i class="fas fa-envelope text-gold me-2"></i> sports@siacollege.edu</li>
                    <li><i class="fas fa-phone text-gold me-2"></i> +91 98765 43210</li>
                    <li><i class="fas fa-map-marker-alt text-gold me-2"></i> SIA College, Mumbai, India</li>
                </ul>
            </div>
        </div>
        <hr class="border-secondary">
        <p class="text-center text-muted small mb-0">© 2026 SIA College Sports Portal. BSc IT Semester 5 Project.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
