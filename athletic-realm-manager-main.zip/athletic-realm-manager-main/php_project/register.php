<?php
include 'db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = mysqli_real_escape_string($conn, trim($_POST['full_name']));
    $username = mysqli_real_escape_string($conn, trim($_POST['username']));
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $course = mysqli_real_escape_string($conn, $_POST['course']);
    $year = (int)$_POST['year'];

    // Validation
    if (empty($full_name) || empty($username) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        // Check duplicate username
        $check = mysqli_query($conn, "SELECT id FROM users WHERE username = '$username'");
        if (mysqli_num_rows($check) > 0) {
            $error = "Username already taken.";
        } else {
            // Check duplicate email
            $check_email = mysqli_query($conn, "SELECT id FROM users WHERE email = '$email'");
            if (mysqli_num_rows($check_email) > 0) {
                $error = "Email already registered.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $sql = "INSERT INTO users (full_name, username, email, password, course, year) 
                        VALUES ('$full_name', '$username', '$email', '$hashed_password', '$course', $year)";
                if (mysqli_query($conn, $sql)) {
                    $success = "Registration successful! Redirecting to login...";
                    header("refresh:2;url=login.php");
                } else {
                    $error = "Registration failed. Please try again.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - SIA Sports Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <i class="fas fa-trophy text-gold me-2 fs-4"></i>
            <span class="brand-text">SIA SPORTS</span>
        </a>
        <div class="ms-auto">
            <a href="login.php" class="nav-link d-inline text-muted">Login</a>
        </div>
    </div>
</nav>

<div class="container d-flex align-items-center justify-content-center" style="min-height:100vh; padding-top:80px; padding-bottom:40px;">
    <div class="form-dark w-100" style="max-width:480px;">
        <div class="text-center mb-4">
            <i class="fas fa-user-plus text-gold fs-1 mb-3"></i>
            <h2 class="fw-bold">Register</h2>
            <p class="text-muted small">Create your SIA Sports account</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger-dark"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success-dark"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <input type="text" name="full_name" class="form-control form-control-dark" placeholder="Full Name" required value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <input type="text" name="username" class="form-control form-control-dark" placeholder="Username" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <input type="email" name="email" class="form-control form-control-dark" placeholder="Email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <input type="password" name="password" class="form-control form-control-dark" placeholder="Password" required>
            </div>
            <div class="mb-3">
                <input type="password" name="confirm_password" class="form-control form-control-dark" placeholder="Confirm Password" required>
            </div>
            <div class="mb-3">
                <select name="course" class="form-select form-select-dark" required>
                    <option value="">Select Course</option>
                    <option value="BSc IT">BSc IT</option>
                    <option value="BCA">BCA</option>
                    <option value="BMS">BMS</option>
                    <option value="BCom">BCom</option>
                    <option value="BA">BA</option>
                </select>
            </div>
            <div class="mb-4">
                <select name="year" class="form-select form-select-dark" required>
                    <option value="">Select Year</option>
                    <option value="1">First Year</option>
                    <option value="2">Second Year</option>
                    <option value="3">Third Year</option>
                </select>
            </div>
            <button type="submit" class="btn btn-gold w-100 py-3 fs-5">Register</button>
        </form>
        <p class="text-center text-muted small mt-3">
            Already have an account? <a href="login.php" class="text-gold text-decoration-none">Login</a>
        </p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
