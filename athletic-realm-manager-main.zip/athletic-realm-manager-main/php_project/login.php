<?php
include 'db.php';

$error = '';
$login_type = isset($_POST['login_type']) ? $_POST['login_type'] : 'student';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $password = $_POST['password'];
    $login_type = $_POST['login_type'];

    if ($login_type === 'admin') {
        $query = mysqli_query($conn, "SELECT * FROM admin WHERE email = '$email'");
        if (mysqli_num_rows($query) > 0) {
            $admin = mysqli_fetch_assoc($query);
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['username'];
                $_SESSION['role'] = 'admin';
                header("Location: admin/dashboard.php");
                exit;
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "Admin not found.";
        }
    } else {
        $query = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'");
        if (mysqli_num_rows($query) > 0) {
            $user = mysqli_fetch_assoc($query);
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['role'] = 'student';
                header("Location: student/dashboard.php");
                exit;
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "Account not found.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SIA Sports Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <i class="fas fa-trophy text-gold me-2 fs-4"></i>
            <span class="brand-text">SIA SPORTS</span>
        </a>
    </div>
</nav>

<div class="container d-flex align-items-center justify-content-center" style="min-height:100vh;">
    <div class="form-dark w-100" style="max-width:440px;">
        <div class="text-center mb-4">
            <i class="fas fa-sign-in-alt text-gold fs-1 mb-3" id="loginIcon"></i>
            <h2 class="fw-bold" id="loginTitle">Student Login</h2>
            <p class="text-muted small">Access your SIA Sports dashboard</p>
        </div>

        <!-- Toggle -->
        <div class="login-toggle mb-4">
            <button type="button" class="toggle-btn active-student" id="btnStudent" onclick="switchLogin('student')">Student</button>
            <button type="button" class="toggle-btn" id="btnAdmin" onclick="switchLogin('admin')">Admin</button>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger-dark"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <input type="hidden" name="login_type" id="loginType" value="<?= htmlspecialchars($login_type) ?>">
            <div class="mb-3">
                <input type="email" name="email" class="form-control form-control-dark" placeholder="Email" required>
            </div>
            <div class="mb-4">
                <input type="password" name="password" class="form-control form-control-dark" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-gold w-100 py-3 fs-5" id="loginBtn">Login</button>
        </form>
        <p class="text-center text-muted small mt-3">
            Don't have an account? <a href="register.php" class="text-gold text-decoration-none">Register</a>
        </p>
    </div>
</div>

<script>
function switchLogin(type) {
    document.getElementById('loginType').value = type;
    const btnStudent = document.getElementById('btnStudent');
    const btnAdmin = document.getElementById('btnAdmin');
    const loginTitle = document.getElementById('loginTitle');
    const loginBtn = document.getElementById('loginBtn');

    if (type === 'admin') {
        btnAdmin.className = 'toggle-btn active-admin';
        btnStudent.className = 'toggle-btn';
        loginTitle.textContent = 'Admin Login';
        loginBtn.className = 'btn btn-blue w-100 py-3 fs-5';
    } else {
        btnStudent.className = 'toggle-btn active-student';
        btnAdmin.className = 'toggle-btn';
        loginTitle.textContent = 'Student Login';
        loginBtn.className = 'btn btn-gold w-100 py-3 fs-5';
    }
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
