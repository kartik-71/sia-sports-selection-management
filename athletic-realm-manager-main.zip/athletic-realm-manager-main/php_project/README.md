# SIA Sports Portal - PHP/MySQL Setup Guide

## How to Run on XAMPP

### Step 1: Install XAMPP
Download and install from https://www.apachefriends.org/

### Step 2: Copy Project Files
Copy the entire `php_project` folder contents into:
```
C:\xampp\htdocs\sia_sports_portal\
```

Your folder structure should be:
```
C:\xampp\htdocs\sia_sports_portal\
├── index.php
├── login.php
├── register.php
├── logout.php
├── db.php
├── database.sql
├── css/
│   └── style.css
├── admin/
│   └── dashboard.php
└── student/
    └── dashboard.php
```

### Step 3: Start XAMPP
1. Open XAMPP Control Panel
2. Start **Apache** and **MySQL**

### Step 4: Create Database
1. Open browser → go to `http://localhost/phpmyadmin`
2. Click **"New"** to create database named `sia_sports`
3. Go to the **SQL** tab
4. Copy-paste the contents of `database.sql` and click **Go**

### Step 5: Run the Project
Open browser → go to `http://localhost/sia_sports_portal/`

### Default Admin Login
- **Email:** admin@siacollege.edu
- **Password:** password

### Features Included
- ✅ Student Registration with validation
- ✅ Student & Admin Login with session management
- ✅ Password hashing (password_hash / password_verify)
- ✅ Student Dashboard with Chart.js (performance & attendance)
- ✅ Admin Dashboard with statistics & charts
- ✅ Manage Sports (add/delete)
- ✅ Manage Students (search/filter/delete)
- ✅ Mark Attendance
- ✅ Role-based access control
- ✅ Dark sports theme with responsive design
- ✅ Bootstrap 5 responsive layout
