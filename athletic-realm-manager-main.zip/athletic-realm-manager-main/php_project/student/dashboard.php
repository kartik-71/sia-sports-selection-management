<?php
include '../db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = $user_id"));

// Get performance data
$perf_query = mysqli_query($conn, "SELECT month, score FROM performance WHERE user_id = $user_id ORDER BY id ASC");
$perf_labels = [];
$perf_data = [];
while ($row = mysqli_fetch_assoc($perf_query)) {
    $perf_labels[] = $row['month'];
    $perf_data[] = $row['score'];
}

// Get attendance data
$total_att = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM attendance WHERE user_id = $user_id"))['total'];
$present = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as cnt FROM attendance WHERE user_id = $user_id AND status='present'"))['cnt'];
$absent = $total_att - $present;
$att_percent = $total_att > 0 ? round(($present / $total_att) * 100) : 0;

// Get selection status
$selection = mysqli_fetch_assoc(mysqli_query($conn, "SELECT s.selected, sp.name as sport_name FROM selection s JOIN sports sp ON s.sport_id = sp.id WHERE s.user_id = $user_id LIMIT 1"));

// Get announcements
$announcements = mysqli_query($conn, "SELECT * FROM announcements ORDER BY created_at DESC LIMIT 5");

$tab = isset($_GET['tab']) ? $_GET['tab'] : 'overview';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - SIA Sports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<!-- Top bar -->
<nav class="navbar navbar-dark" style="background:var(--bg-card);border-bottom:1px solid var(--border);">
    <div class="container-fluid px-4">
        <span class="navbar-brand">
            <i class="fas fa-trophy text-gold me-2"></i>
            <span class="brand-text">SIA SPORTS</span>
        </span>
        <div class="d-flex align-items-center gap-3">
            <span class="text-muted small d-none d-sm-inline">Welcome, <?= htmlspecialchars($user['full_name']) ?></span>
            <a href="../logout.php" class="text-danger small text-decoration-none">
                <i class="fas fa-sign-out-alt me-1"></i>Logout
            </a>
        </div>
    </div>
</nav>

<div class="d-flex">
    <!-- Sidebar -->
    <aside class="sidebar d-none d-md-block p-3">
        <nav class="d-flex flex-column gap-1">
            <a href="?tab=overview" class="sidebar-link <?= $tab==='overview'?'active':'' ?>">
                <i class="fas fa-chart-bar"></i> Overview
            </a>
            <a href="?tab=profile" class="sidebar-link <?= $tab==='profile'?'active':'' ?>">
                <i class="fas fa-user"></i> Profile
            </a>
            <a href="?tab=announcements" class="sidebar-link <?= $tab==='announcements'?'active':'' ?>">
                <i class="fas fa-bell"></i> Announcements
            </a>
        </nav>
    </aside>

    <!-- Main -->
    <main class="flex-grow-1 p-4">
        <!-- Mobile tabs -->
        <div class="d-flex d-md-none gap-2 mb-4 overflow-auto">
            <a href="?tab=overview" class="sidebar-link <?= $tab==='overview'?'active':'' ?> text-nowrap"><i class="fas fa-chart-bar"></i> Overview</a>
            <a href="?tab=profile" class="sidebar-link <?= $tab==='profile'?'active':'' ?> text-nowrap"><i class="fas fa-user"></i> Profile</a>
            <a href="?tab=announcements" class="sidebar-link <?= $tab==='announcements'?'active':'' ?> text-nowrap"><i class="fas fa-bell"></i> Announcements</a>
        </div>

        <?php if ($tab === 'overview'): ?>
        <h2 class="fw-bold mb-4">Dashboard Overview</h2>

        <div class="row g-3 mb-4">
            <div class="col-sm-4">
                <div class="stat-card">
                    <p class="text-muted small mb-1">Selection Status</p>
                    <h4 class="fw-bold" style="color:var(--green);">
                        <i class="fas fa-check-circle me-1"></i>
                        <?= $selection && $selection['selected'] ? 'Selected' : 'Not Selected' ?>
                    </h4>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="stat-card">
                    <p class="text-muted small mb-1">Sport</p>
                    <h4 class="fw-bold text-gold"><?= htmlspecialchars($selection['sport_name'] ?? 'Not Assigned') ?></h4>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="stat-card">
                    <p class="text-muted small mb-1">Attendance</p>
                    <h4 class="fw-bold"><?= $att_percent ?>%</h4>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-6">
                <div class="stat-card">
                    <h5 class="fw-bold mb-3">Performance Trend</h5>
                    <canvas id="perfChart" height="200"></canvas>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="stat-card">
                    <h5 class="fw-bold mb-3">Attendance Breakdown</h5>
                    <canvas id="attChart" height="200"></canvas>
                </div>
            </div>
        </div>

        <script>
        new Chart(document.getElementById('perfChart'), {
            type: 'bar',
            data: {
                labels: <?= json_encode($perf_labels) ?>,
                datasets: [{
                    label: 'Score',
                    data: <?= json_encode($perf_data) ?>,
                    backgroundColor: '#f5a623',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true, grid: { color: '#2a3040' }, ticks: { color: '#7a8299' } },
                    x: { grid: { display: false }, ticks: { color: '#7a8299' } }
                },
                plugins: { legend: { display: false } }
            }
        });

        new Chart(document.getElementById('attChart'), {
            type: 'doughnut',
            data: {
                labels: ['Present', 'Absent'],
                datasets: [{
                    data: [<?= $present ?>, <?= $absent ?>],
                    backgroundColor: ['#22c55e', '#ef4444'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                cutout: '60%',
                plugins: { legend: { labels: { color: '#e2e6ed' } } }
            }
        });
        </script>

        <?php elseif ($tab === 'profile'): ?>
        <h2 class="fw-bold mb-4">My Profile</h2>
        <div class="stat-card" style="max-width:500px;">
            <?php
            $fields = [
                'Name' => $user['full_name'],
                'Username' => $user['username'],
                'Email' => $user['email'],
                'Course' => $user['course'],
                'Year' => 'Year ' . $user['year'],
                'Sport' => $selection['sport_name'] ?? 'Not Assigned'
            ];
            foreach ($fields as $label => $value):
            ?>
            <div class="d-flex justify-content-between border-bottom py-3" style="border-color:var(--border)!important;">
                <span class="text-muted small"><?= $label ?></span>
                <span class="small fw-medium"><?= htmlspecialchars($value) ?></span>
            </div>
            <?php endforeach; ?>
        </div>

        <?php elseif ($tab === 'announcements'): ?>
        <h2 class="fw-bold mb-4">Announcements</h2>
        <?php while ($ann = mysqli_fetch_assoc($announcements)): ?>
        <div class="stat-card mb-3">
            <div class="d-flex gap-3">
                <i class="fas fa-calendar text-gold mt-1"></i>
                <div>
                    <h6 class="fw-bold mb-1"><?= htmlspecialchars($ann['title']) ?></h6>
                    <p class="text-muted small mb-0"><?= htmlspecialchars($ann['description']) ?></p>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
        <?php endif; ?>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
