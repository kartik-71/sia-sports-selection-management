<?php
include '../db.php';
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$tab = isset($_GET['tab']) ? $_GET['tab'] : 'overview';

// Stats
$total_students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as cnt FROM users"))['cnt'];
$total_sports = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as cnt FROM sports"))['cnt'];
$selected_players = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as cnt FROM selection WHERE selected=1"))['cnt'];
$total_achievers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as cnt FROM achievers"))['cnt'];

// Handle actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Add Sport
    if (isset($_POST['add_sport'])) {
        $name = mysqli_real_escape_string($conn, $_POST['sport_name']);
        $desc = mysqli_real_escape_string($conn, $_POST['sport_desc']);
        $icon = mysqli_real_escape_string($conn, $_POST['sport_icon']);
        mysqli_query($conn, "INSERT INTO sports (name, description, icon) VALUES ('$name', '$desc', '$icon')");
        header("Location: dashboard.php?tab=sports&msg=Sport+added");
        exit;
    }
    // Delete Sport
    if (isset($_POST['delete_sport'])) {
        $id = (int)$_POST['sport_id'];
        mysqli_query($conn, "DELETE FROM sports WHERE id = $id");
        header("Location: dashboard.php?tab=sports&msg=Sport+deleted");
        exit;
    }
    // Mark Attendance
    if (isset($_POST['mark_attendance'])) {
        $uid = (int)$_POST['uid'];
        $sid = (int)$_POST['sid'];
        $status = $_POST['att_status'] === 'present' ? 'present' : 'absent';
        mysqli_query($conn, "INSERT INTO attendance (user_id, sport_id, date, status) VALUES ($uid, $sid, CURDATE(), '$status')");
        header("Location: dashboard.php?tab=attendance&msg=Attendance+marked");
        exit;
    }
    // Delete Student
    if (isset($_POST['delete_student'])) {
        $id = (int)$_POST['student_id'];
        mysqli_query($conn, "DELETE FROM users WHERE id = $id");
        header("Location: dashboard.php?tab=students&msg=Student+deleted");
        exit;
    }
}

// Sport enrollment data for chart
$sport_chart = mysqli_query($conn, "SELECT sp.name, COUNT(sel.id) as cnt FROM sports sp LEFT JOIN selection sel ON sp.id = sel.sport_id GROUP BY sp.id");
$chart_labels = [];
$chart_data = [];
while ($row = mysqli_fetch_assoc($sport_chart)) {
    $chart_labels[] = $row['name'];
    $chart_data[] = (int)$row['cnt'];
}

// Students list with search/filter
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$sport_filter = isset($_GET['sport']) ? mysqli_real_escape_string($conn, $_GET['sport']) : '';

$student_sql = "SELECT u.*, sp.name as sport_name, sel.selected,
    (SELECT ROUND(COUNT(CASE WHEN a.status='present' THEN 1 END)/NULLIF(COUNT(*),0)*100) FROM attendance a WHERE a.user_id=u.id) as att_percent
    FROM users u 
    LEFT JOIN selection sel ON u.id = sel.user_id 
    LEFT JOIN sports sp ON sel.sport_id = sp.id 
    WHERE 1=1";
if ($search) $student_sql .= " AND u.full_name LIKE '%$search%'";
if ($sport_filter) $student_sql .= " AND sp.name = '$sport_filter'";
$students = mysqli_query($conn, $student_sql);

$all_sports = mysqli_query($conn, "SELECT * FROM sports");
$sports_list = [];
while ($s = mysqli_fetch_assoc($all_sports)) $sports_list[] = $s;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SIA Sports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<!-- Top bar -->
<nav class="navbar navbar-dark" style="background:var(--bg-card);border-bottom:1px solid var(--border);">
    <div class="container-fluid px-4">
        <span class="navbar-brand">
            <i class="fas fa-shield-alt" style="color:var(--blue)"></i>
            <span class="ms-2 fw-bold" style="font-family:'Oswald'">ADMIN <span class="text-gold">PANEL</span></span>
        </span>
        <a href="../logout.php" class="text-danger small text-decoration-none">
            <i class="fas fa-sign-out-alt me-1"></i>Logout
        </a>
    </div>
</nav>

<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-success-dark m-3"><?= htmlspecialchars($_GET['msg']) ?></div>
<?php endif; ?>

<div class="d-flex">
    <!-- Sidebar -->
    <aside class="sidebar d-none d-md-block p-3">
        <nav class="d-flex flex-column gap-1">
            <a href="?tab=overview" class="sidebar-link sidebar-link-admin <?= $tab==='overview'?'active':'' ?>"><i class="fas fa-chart-bar"></i> Overview</a>
            <a href="?tab=students" class="sidebar-link sidebar-link-admin <?= $tab==='students'?'active':'' ?>"><i class="fas fa-users"></i> Students</a>
            <a href="?tab=sports" class="sidebar-link sidebar-link-admin <?= $tab==='sports'?'active':'' ?>"><i class="fas fa-trophy"></i> Sports</a>
            <a href="?tab=attendance" class="sidebar-link sidebar-link-admin <?= $tab==='attendance'?'active':'' ?>"><i class="fas fa-clipboard-list"></i> Attendance</a>
        </nav>
    </aside>

    <main class="flex-grow-1 p-4">
        <!-- Mobile tabs -->
        <div class="d-flex d-md-none gap-2 mb-4 overflow-auto">
            <a href="?tab=overview" class="sidebar-link sidebar-link-admin <?= $tab==='overview'?'active':'' ?> text-nowrap"><i class="fas fa-chart-bar"></i> Overview</a>
            <a href="?tab=students" class="sidebar-link sidebar-link-admin <?= $tab==='students'?'active':'' ?> text-nowrap"><i class="fas fa-users"></i> Students</a>
            <a href="?tab=sports" class="sidebar-link sidebar-link-admin <?= $tab==='sports'?'active':'' ?> text-nowrap"><i class="fas fa-trophy"></i> Sports</a>
            <a href="?tab=attendance" class="sidebar-link sidebar-link-admin <?= $tab==='attendance'?'active':'' ?> text-nowrap"><i class="fas fa-clipboard-list"></i> Attendance</a>
        </div>

        <?php if ($tab === 'overview'): ?>
        <h2 class="fw-bold mb-4">Admin Dashboard</h2>
        <div class="row g-3 mb-4">
            <div class="col-sm-6 col-lg-3">
                <div class="stat-card"><i class="fas fa-users text-gold fs-4 mb-2"></i><h3 class="fw-bold"><?= $total_students ?></h3><p class="text-muted small">Total Students</p></div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="stat-card"><i class="fas fa-trophy fs-4 mb-2" style="color:var(--green)"></i><h3 class="fw-bold"><?= $total_sports ?></h3><p class="text-muted small">Total Sports</p></div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="stat-card"><i class="fas fa-medal fs-4 mb-2" style="color:var(--blue)"></i><h3 class="fw-bold"><?= $selected_players ?></h3><p class="text-muted small">Selected Players</p></div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="stat-card"><i class="fas fa-chart-bar text-gold fs-4 mb-2"></i><h3 class="fw-bold"><?= $total_achievers ?></h3><p class="text-muted small">Achievers</p></div>
            </div>
        </div>
        <div class="stat-card">
            <h5 class="fw-bold mb-3">Students by Sport</h5>
            <canvas id="sportChart" height="150"></canvas>
        </div>
        <script>
        new Chart(document.getElementById('sportChart'), {
            type: 'bar',
            data: {
                labels: <?= json_encode($chart_labels) ?>,
                datasets: [{
                    label: 'Students',
                    data: <?= json_encode($chart_data) ?>,
                    backgroundColor: '#3b82f6',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true, grid: { color: '#2a3040' }, ticks: { color: '#7a8299' } },
                    x: { grid: { display: false }, ticks: { color: '#7a8299' } }
                },
                plugins: { legend: { display: false } }
            }
        });
        </script>

        <?php elseif ($tab === 'students'): ?>
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <h2 class="fw-bold mb-0">Manage Students</h2>
        </div>
        <form class="d-flex gap-3 mb-4 flex-wrap" method="GET">
            <input type="hidden" name="tab" value="students">
            <div class="position-relative flex-grow-1" style="min-width:200px;">
                <i class="fas fa-search position-absolute" style="left:12px;top:12px;color:var(--text-muted)"></i>
                <input type="text" name="search" class="form-control form-control-dark ps-5" placeholder="Search students..." value="<?= htmlspecialchars($search) ?>">
            </div>
            <select name="sport" class="form-select form-select-dark" style="width:auto;">
                <option value="">All Sports</option>
                <?php foreach ($sports_list as $sp): ?>
                <option value="<?= htmlspecialchars($sp['name']) ?>" <?= $sport_filter===$sp['name']?'selected':'' ?>><?= htmlspecialchars($sp['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <button class="btn btn-gold">Filter</button>
        </form>
        <div class="table-dark-custom">
            <table class="table">
                <thead><tr><th>Name</th><th>Course</th><th>Sport</th><th>Attendance</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                <?php while ($st = mysqli_fetch_assoc($students)): ?>
                <tr>
                    <td class="fw-medium"><?= htmlspecialchars($st['full_name']) ?></td>
                    <td class="text-muted"><?= htmlspecialchars($st['course']) ?> - Y<?= $st['year'] ?></td>
                    <td class="text-gold"><?= htmlspecialchars($st['sport_name'] ?? 'N/A') ?></td>
                    <td><?= $st['att_percent'] ?? 0 ?>%</td>
                    <td><span class="<?= $st['selected'] ? 'badge-selected' : 'badge-not-selected' ?>"><?= $st['selected'] ? 'Selected' : 'Not Selected' ?></span></td>
                    <td>
                        <form method="POST" class="d-inline" onsubmit="return confirm('Delete this student?')">
                            <input type="hidden" name="student_id" value="<?= $st['id'] ?>">
                            <button name="delete_student" class="btn btn-sm text-danger p-0"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <?php elseif ($tab === 'sports'): ?>
        <div class="d-flex align-items-center justify-content-between mb-4">
            <h2 class="fw-bold mb-0">Manage Sports</h2>
            <button class="btn btn-blue btn-sm" data-bs-toggle="collapse" data-bs-target="#addSportForm"><i class="fas fa-plus me-1"></i> Add Sport</button>
        </div>
        <div class="collapse mb-4" id="addSportForm">
            <div class="stat-card">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-4"><input name="sport_name" class="form-control form-control-dark" placeholder="Sport Name" required></div>
                        <div class="col-md-2"><input name="sport_icon" class="form-control form-control-dark" placeholder="Icon emoji" required></div>
                        <div class="col-md-4"><input name="sport_desc" class="form-control form-control-dark" placeholder="Description"></div>
                        <div class="col-md-2"><button name="add_sport" class="btn btn-gold w-100">Add</button></div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row g-3">
            <?php
            $sp_list = mysqli_query($conn, "SELECT s.*, (SELECT COUNT(*) FROM selection WHERE sport_id=s.id) as student_count FROM sports s");
            while ($sp = mysqli_fetch_assoc($sp_list)):
            ?>
            <div class="col-md-4">
                <div class="stat-card">
                    <span style="font-size:2rem;"><?= htmlspecialchars($sp['icon']) ?></span>
                    <h5 class="fw-bold mt-2"><?= htmlspecialchars($sp['name']) ?></h5>
                    <p class="text-muted small"><?= $sp['student_count'] ?> enrolled students</p>
                    <form method="POST" class="d-inline" onsubmit="return confirm('Delete this sport?')">
                        <input type="hidden" name="sport_id" value="<?= $sp['id'] ?>">
                        <button name="delete_sport" class="btn btn-sm text-danger p-0"><i class="fas fa-trash me-1"></i>Delete</button>
                    </form>
                </div>
            </div>
            <?php endwhile; ?>
        </div>

        <?php elseif ($tab === 'attendance'): ?>
        <h2 class="fw-bold mb-4">Mark Attendance</h2>
        <div class="table-dark-custom">
            <table class="table">
                <thead><tr><th>Student</th><th>Sport</th><th>Current %</th><th>Today</th></tr></thead>
                <tbody>
                <?php
                $att_students = mysqli_query($conn, "SELECT u.id, u.full_name, sp.name as sport_name, sp.id as sport_id,
                    (SELECT ROUND(COUNT(CASE WHEN a.status='present' THEN 1 END)/NULLIF(COUNT(*),0)*100) FROM attendance a WHERE a.user_id=u.id) as att_pct
                    FROM users u JOIN selection sel ON u.id=sel.user_id JOIN sports sp ON sel.sport_id=sp.id");
                while ($as = mysqli_fetch_assoc($att_students)):
                ?>
                <tr>
                    <td class="fw-medium"><?= htmlspecialchars($as['full_name']) ?></td>
                    <td class="text-gold"><?= htmlspecialchars($as['sport_name']) ?></td>
                    <td><?= $as['att_pct'] ?? 0 ?>%</td>
                    <td>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="uid" value="<?= $as['id'] ?>">
                            <input type="hidden" name="sid" value="<?= $as['sport_id'] ?>">
                            <input type="hidden" name="mark_attendance" value="1">
                            <button name="att_status" value="present" class="btn btn-sm badge-selected me-1">Present</button>
                            <button name="att_status" value="absent" class="btn btn-sm badge-not-selected">Absent</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
