-- Add photo_url to achievers
ALTER TABLE public.achievers ADD COLUMN IF NOT EXISTS photo_url text;

-- Create storage bucket for achiever photos
INSERT INTO storage.buckets (id, name, public) VALUES ('achiever-photos', 'achiever-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for achiever photos
CREATE POLICY "Anyone can view achiever photos" ON storage.objects FOR SELECT USING (bucket_id = 'achiever-photos');
CREATE POLICY "Admins can upload achiever photos" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'achiever-photos' AND public.is_admin(auth.uid()));
CREATE POLICY "Admins can delete achiever photos" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'achiever-photos' AND public.is_admin(auth.uid()));

-- Allow students to manage their own sport enrollments
CREATE POLICY "Students can insert own enrollment" ON public.student_sports FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Students can update own enrollment" ON public.student_sports FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Students can delete own enrollment" ON public.student_sports FOR DELETE TO authenticated USING (auth.uid() = user_id);